/*==============================================================*/
/* DBMS name:      Sybase SQL Anywhere 12                       */
/* Created on:     12/01/2025 23:43:02                          */
/*==============================================================*/


if exists(select 1 from sys.sysforeignkey where role='FK_AUTOR_CONTRATO__CONTRATO') then
    alter table AUTOR
       delete foreign key FK_AUTOR_CONTRATO__CONTRATO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_CONTRATO_CONTRATO__AUTOR') then
    alter table CONTRATO
       delete foreign key FK_CONTRATO_CONTRATO__AUTOR
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_CONTRATO_CONTRATO__EDITORA') then
    alter table CONTRATO
       delete foreign key FK_CONTRATO_CONTRATO__EDITORA
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_EDITORA_CONTRATO__CONTRATO') then
    alter table EDITORA
       delete foreign key FK_EDITORA_CONTRATO__CONTRATO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_EDITORA__EDITORA_T_TIPO') then
    alter table EDITORA_TEM_TIPO
       delete foreign key FK_EDITORA__EDITORA_T_TIPO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_EDITORA__EDITORA_T_EDITORA') then
    alter table EDITORA_TEM_TIPO
       delete foreign key FK_EDITORA__EDITORA_T_EDITORA
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_ENCOMEND_EMPREGADO_EMPREGAD') then
    alter table ENCOMENDA
       delete foreign key FK_ENCOMEND_EMPREGADO_EMPREGAD
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_ENCOMEND_ENCOMENDA_ENCOMEND') then
    alter table ENCOMENDA_TEM_PRODUTOS
       delete foreign key FK_ENCOMEND_ENCOMENDA_ENCOMEND
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_ENCOMEND_ENCOMENDA_PRODUTO') then
    alter table ENCOMENDA_TEM_PRODUTOS
       delete foreign key FK_ENCOMEND_ENCOMENDA_PRODUTO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_FORNECED_FORNECEDO_FORNECED') then
    alter table FORNECEDOR_TEM_PRODUTOS
       delete foreign key FK_FORNECED_FORNECEDO_FORNECED
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_FORNECED_FORNECEDO_PRODUTO') then
    alter table FORNECEDOR_TEM_PRODUTOS
       delete foreign key FK_FORNECED_FORNECEDO_PRODUTO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_LOCALIZA_PRODUTO_T_PRODUTO') then
    alter table LOCALIZACAO_PRODUTO
       delete foreign key FK_LOCALIZA_PRODUTO_T_PRODUTO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRODUTO_PRODUTO_T_EDITORA') then
    alter table PRODUTO
       delete foreign key FK_PRODUTO_PRODUTO_T_EDITORA
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRODUTO_PRODUTO_T_LOCALIZA') then
    alter table PRODUTO
       delete foreign key FK_PRODUTO_PRODUTO_T_LOCALIZA
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRODUTO_PRODUTO_T_TIPO') then
    alter table PRODUTO
       delete foreign key FK_PRODUTO_PRODUTO_T_TIPO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRODUTO__PRODUTO_T_PRODUTO') then
    alter table PRODUTO_TEM_AUTOR
       delete foreign key FK_PRODUTO__PRODUTO_T_PRODUTO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRODUTO__PRODUTO_T_AUTOR') then
    alter table PRODUTO_TEM_AUTOR
       delete foreign key FK_PRODUTO__PRODUTO_T_AUTOR
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRODUTO__PRODUTO_T_PRODUTO') then
    alter table PRODUTO_TEM_MUSICA
       delete foreign key FK_PRODUTO__PRODUTO_T_PRODUTO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_PRODUTO__PRODUTO_T_MUSICA') then
    alter table PRODUTO_TEM_MUSICA
       delete foreign key FK_PRODUTO__PRODUTO_T_MUSICA
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_TIPO_PRODUTO_T_PRODUTO') then
    alter table TIPO
       delete foreign key FK_TIPO_PRODUTO_T_PRODUTO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_VENDAS_PRODUTO_T_PRODUTO') then
    alter table VENDAS
       delete foreign key FK_VENDAS_PRODUTO_T_PRODUTO
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_VENDAS_REALIZAM_CLIENTE_') then
    alter table VENDAS
       delete foreign key FK_VENDAS_REALIZAM_CLIENTE_
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_VENDAS_VENDAS_TE_PROMOCOE') then
    alter table VENDAS
       delete foreign key FK_VENDAS_VENDAS_TE_PROMOCOE
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_VENDAS_VENDA_TEM_EMPREGAD') then
    alter table VENDAS
       delete foreign key FK_VENDAS_VENDA_TEM_EMPREGAD
end if;

drop index if exists AUTOR.CONTRATO_TEM_AUTOR_FK;

drop index if exists AUTOR.AUTOR_PK;

drop table if exists AUTOR;

drop index if exists CLIENTE_ESPECIAIS.CLIENTE_ESPECIAIS_PK;

drop table if exists CLIENTE_ESPECIAIS;

drop index if exists CONTRATO.CONTRATO_TEM_EDITORA2_FK;

drop index if exists CONTRATO.CONTRATO_TEM_AUTOR2_FK;

drop index if exists CONTRATO.CONTRATO_PK;

drop table if exists CONTRATO;

drop index if exists EDITORA.CONTRATO_TEM_EDITORA_FK;

drop index if exists EDITORA.EDITORA_PK;

drop table if exists EDITORA;

drop index if exists EDITORA_TEM_TIPO.EDITORA_TEM_TIPO2_FK;

drop index if exists EDITORA_TEM_TIPO.EDITORA_TEM_TIPO_FK;

drop index if exists EDITORA_TEM_TIPO.EDITORA_TEM_TIPO_PK;

drop table if exists EDITORA_TEM_TIPO;

drop index if exists EMPREGADOS.EMPREGADOS_PK;

drop table if exists EMPREGADOS;

drop index if exists ENCOMENDA.EMPREGADO_ENCOMENDA_FK;

drop index if exists ENCOMENDA.ENCOMENDA_PK;

drop table if exists ENCOMENDA;

drop index if exists ENCOMENDA_TEM_PRODUTOS.ENCOMENDA_TEM_PRODUTOS2_FK;

drop index if exists ENCOMENDA_TEM_PRODUTOS.ENCOMENDA_TEM_PRODUTOS_FK;

drop index if exists ENCOMENDA_TEM_PRODUTOS.ENCOMENDA_TEM_PRODUTOS_PK;

drop table if exists ENCOMENDA_TEM_PRODUTOS;

drop index if exists FORNECEDOR.FORNECEDOR_PK;

drop table if exists FORNECEDOR;

drop index if exists FORNECEDOR_TEM_PRODUTOS.FORNECEDOR_TEM_PRODUTOS2_FK;

drop index if exists FORNECEDOR_TEM_PRODUTOS.FORNECEDOR_TEM_PRODUTOS_FK;

drop index if exists FORNECEDOR_TEM_PRODUTOS.FORNECEDOR_TEM_PRODUTOS_PK;

drop table if exists FORNECEDOR_TEM_PRODUTOS;

drop index if exists LOCALIZACAO_PRODUTO.PRODUTO_TEM_LOCALIZACAO2_FK;

drop index if exists LOCALIZACAO_PRODUTO.LOCALIZACAO_PRODUTO_PK;

drop table if exists LOCALIZACAO_PRODUTO;

drop index if exists MUSICA.MUSICA_PK;

drop table if exists MUSICA;

drop index if exists PRODUTO.PRODUTO_TEM_TIPO2_FK;

drop index if exists PRODUTO.PRODUTO_TEM_EDITORA_FK;

drop index if exists PRODUTO.PRODUTO_TEM_LOCALIZACAO_FK;

drop index if exists PRODUTO.PRODUTO_PK;

drop table if exists PRODUTO;

drop index if exists PRODUTO_TEM_AUTOR.PRODUTO_TEM_AUTOR2_FK;

drop index if exists PRODUTO_TEM_AUTOR.PRODUTO_TEM_AUTOR_FK;

drop index if exists PRODUTO_TEM_AUTOR.PRODUTO_TEM_AUTOR_PK;

drop table if exists PRODUTO_TEM_AUTOR;

drop index if exists PRODUTO_TEM_MUSICA.PRODUTO_TEM_MUSICA2_FK;

drop index if exists PRODUTO_TEM_MUSICA.PRODUTO_TEM_MUSICA_FK;

drop index if exists PRODUTO_TEM_MUSICA.PRODUTO_TEM_MUSICA_PK;

drop table if exists PRODUTO_TEM_MUSICA;

drop index if exists PROMOCOES.PROMOCOES_PK;

drop table if exists PROMOCOES;

drop index if exists TIPO.PRODUTO_TEM_TIPO_FK;

drop index if exists TIPO.TIPO_PK;

drop table if exists TIPO;

drop index if exists VENDAS.VENDA_TEM_EMPREGADO_FK;

drop index if exists VENDAS.PRODUTO_TEM_VARIAS_VENDAS_FK;

drop index if exists VENDAS.REALIZAM_FK;

drop index if exists VENDAS.VENDAS_TEM_PROMOCAO_FK;

drop index if exists VENDAS.VENDAS_PK;

drop table if exists VENDAS;

/*==============================================================*/
/* Table: AUTOR                                                 */
/*==============================================================*/
create table AUTOR 
(
   ID_AUTOR             integer                        not null,
   ID_CONTRATO          integer                        null,
   NOME                 varchar(150)                   null,
   DATA_NASCIMENTO      timestamp                      null,
   EMAIL                varchar(200)                   null,
   PAGINA_WEB           varchar(150)                   null,
   MORADA               varchar(150)                   null,
   CLUBE_DE_FAS         varchar(150)                   null,
   OBSERVACOES          varchar(150)                   null,
   constraint PK_AUTOR primary key (ID_AUTOR)
);

/*==============================================================*/
/* Index: AUTOR_PK                                              */
/*==============================================================*/
create unique index AUTOR_PK on AUTOR (
ID_AUTOR ASC
);

/*==============================================================*/
/* Index: CONTRATO_TEM_AUTOR_FK                                 */
/*==============================================================*/
create index CONTRATO_TEM_AUTOR_FK on AUTOR (
ID_CONTRATO ASC
);

/*==============================================================*/
/* Table: CLIENTE_ESPECIAIS                                     */
/*==============================================================*/
create table CLIENTE_ESPECIAIS 
(
   ID_CLIENTE           integer                        not null,
   NOME                 varchar(150)                   null,
   EMAIL                varchar(200)                   null,
   constraint PK_CLIENTE_ESPECIAIS primary key (ID_CLIENTE)
);

/*==============================================================*/
/* Index: CLIENTE_ESPECIAIS_PK                                  */
/*==============================================================*/
create unique index CLIENTE_ESPECIAIS_PK on CLIENTE_ESPECIAIS (
ID_CLIENTE ASC
);

/*==============================================================*/
/* Table: CONTRATO                                              */
/*==============================================================*/
create table CONTRATO 
(
   ID_CONTRATO          integer                        not null,
   ID_EDITORA           integer                        not null,
   ID_AUTOR             integer                        not null,
   DATA_INICIO          timestamp                      null,
   DATA_FIM             timestamp                      null,
   constraint PK_CONTRATO primary key (ID_CONTRATO)
);

/*==============================================================*/
/* Index: CONTRATO_PK                                           */
/*==============================================================*/
create unique index CONTRATO_PK on CONTRATO (
ID_CONTRATO ASC
);

/*==============================================================*/
/* Index: CONTRATO_TEM_AUTOR2_FK                                */
/*==============================================================*/
create index CONTRATO_TEM_AUTOR2_FK on CONTRATO (
ID_AUTOR ASC
);

/*==============================================================*/
/* Index: CONTRATO_TEM_EDITORA2_FK                              */
/*==============================================================*/
create index CONTRATO_TEM_EDITORA2_FK on CONTRATO (
ID_EDITORA ASC
);

/*==============================================================*/
/* Table: EDITORA                                               */
/*==============================================================*/
create table EDITORA 
(
   ID_EDITORA           integer                        not null,
   ID_CONTRATO          integer                        null,
   NOME                 varchar(150)                   null,
   MORADA               varchar(150)                   null,
   EMAIL                varchar(200)                   null,
   PAGINA_WEB           varchar(150)                   null,
   ESTILO_MUSICAL       varchar(150)                   null,
   OBSERVACOES          varchar(150)                   null,
   constraint PK_EDITORA primary key (ID_EDITORA)
);

/*==============================================================*/
/* Index: EDITORA_PK                                            */
/*==============================================================*/
create unique index EDITORA_PK on EDITORA (
ID_EDITORA ASC
);

/*==============================================================*/
/* Index: CONTRATO_TEM_EDITORA_FK                               */
/*==============================================================*/
create index CONTRATO_TEM_EDITORA_FK on EDITORA (
ID_CONTRATO ASC
);

/*==============================================================*/
/* Table: EDITORA_TEM_TIPO                                      */
/*==============================================================*/
create table EDITORA_TEM_TIPO 
(
   ID_TIPO              integer                        not null,
   ID_EDITORA           integer                        not null,
   constraint PK_EDITORA_TEM_TIPO primary key clustered (ID_TIPO, ID_EDITORA)
);

/*==============================================================*/
/* Index: EDITORA_TEM_TIPO_PK                                   */
/*==============================================================*/
create unique clustered index EDITORA_TEM_TIPO_PK on EDITORA_TEM_TIPO (
ID_TIPO ASC,
ID_EDITORA ASC
);

/*==============================================================*/
/* Index: EDITORA_TEM_TIPO_FK                                   */
/*==============================================================*/
create index EDITORA_TEM_TIPO_FK on EDITORA_TEM_TIPO (
ID_TIPO ASC
);

/*==============================================================*/
/* Index: EDITORA_TEM_TIPO2_FK                                  */
/*==============================================================*/
create index EDITORA_TEM_TIPO2_FK on EDITORA_TEM_TIPO (
ID_EDITORA ASC
);

/*==============================================================*/
/* Table: EMPREGADOS                                            */
/*==============================================================*/
create table EMPREGADOS 
(
   ID_EMPREGADOS        integer                        not null,
   NOME                 varchar(150)                   null,
   DATA_ENTRADA         timestamp                      null,
   DATA_SAIDA           timestamp                      null,
   constraint PK_EMPREGADOS primary key (ID_EMPREGADOS)
);

/*==============================================================*/
/* Index: EMPREGADOS_PK                                         */
/*==============================================================*/
create unique index EMPREGADOS_PK on EMPREGADOS (
ID_EMPREGADOS ASC
);

/*==============================================================*/
/* Table: ENCOMENDA                                             */
/*==============================================================*/
create table ENCOMENDA 
(
   ID_ENCOMENDA         integer                        not null,
   ID_EMPREGADOS        integer                        null,
   DATA                 timestamp                      null,
   ESTADO               varchar(50)                    null,
   constraint PK_ENCOMENDA primary key (ID_ENCOMENDA)
);

/*==============================================================*/
/* Index: ENCOMENDA_PK                                          */
/*==============================================================*/
create unique index ENCOMENDA_PK on ENCOMENDA (
ID_ENCOMENDA ASC
);

/*==============================================================*/
/* Index: EMPREGADO_ENCOMENDA_FK                                */
/*==============================================================*/
create index EMPREGADO_ENCOMENDA_FK on ENCOMENDA (
ID_EMPREGADOS ASC
);

/*==============================================================*/
/* Table: ENCOMENDA_TEM_PRODUTOS                                */
/*==============================================================*/
create table ENCOMENDA_TEM_PRODUTOS 
(
   ID_ENCOMENDA         integer                        not null,
   ID_PRODUTO           integer                        not null,
   constraint PK_ENCOMENDA_TEM_PRODUTOS primary key clustered (ID_ENCOMENDA, ID_PRODUTO)
);

/*==============================================================*/
/* Index: ENCOMENDA_TEM_PRODUTOS_PK                             */
/*==============================================================*/
create unique clustered index ENCOMENDA_TEM_PRODUTOS_PK on ENCOMENDA_TEM_PRODUTOS (
ID_ENCOMENDA ASC,
ID_PRODUTO ASC
);

/*==============================================================*/
/* Index: ENCOMENDA_TEM_PRODUTOS_FK                             */
/*==============================================================*/
create index ENCOMENDA_TEM_PRODUTOS_FK on ENCOMENDA_TEM_PRODUTOS (
ID_ENCOMENDA ASC
);

/*==============================================================*/
/* Index: ENCOMENDA_TEM_PRODUTOS2_FK                            */
/*==============================================================*/
create index ENCOMENDA_TEM_PRODUTOS2_FK on ENCOMENDA_TEM_PRODUTOS (
ID_PRODUTO ASC
);

/*==============================================================*/
/* Table: FORNECEDOR                                            */
/*==============================================================*/
create table FORNECEDOR 
(
   ID_ATRIBUTO          integer                        not null,
   NOME                 varchar(150)                   null,
   MORADA               varchar(150)                   null,
   CONTACTO             integer                        null,
   EMAIL                varchar(200)                   null,
   OBSERVACOES          varchar(150)                   null,
   constraint PK_FORNECEDOR primary key (ID_ATRIBUTO)
);

/*==============================================================*/
/* Index: FORNECEDOR_PK                                         */
/*==============================================================*/
create unique index FORNECEDOR_PK on FORNECEDOR (
ID_ATRIBUTO ASC
);

/*==============================================================*/
/* Table: FORNECEDOR_TEM_PRODUTOS                               */
/*==============================================================*/
create table FORNECEDOR_TEM_PRODUTOS 
(
   ID_ATRIBUTO          integer                        not null,
   ID_PRODUTO           integer                        not null,
   constraint PK_FORNECEDOR_TEM_PRODUTOS primary key clustered (ID_ATRIBUTO, ID_PRODUTO)
);

/*==============================================================*/
/* Index: FORNECEDOR_TEM_PRODUTOS_PK                            */
/*==============================================================*/
create unique clustered index FORNECEDOR_TEM_PRODUTOS_PK on FORNECEDOR_TEM_PRODUTOS (
ID_ATRIBUTO ASC,
ID_PRODUTO ASC
);

/*==============================================================*/
/* Index: FORNECEDOR_TEM_PRODUTOS_FK                            */
/*==============================================================*/
create index FORNECEDOR_TEM_PRODUTOS_FK on FORNECEDOR_TEM_PRODUTOS (
ID_ATRIBUTO ASC
);

/*==============================================================*/
/* Index: FORNECEDOR_TEM_PRODUTOS2_FK                           */
/*==============================================================*/
create index FORNECEDOR_TEM_PRODUTOS2_FK on FORNECEDOR_TEM_PRODUTOS (
ID_PRODUTO ASC
);

/*==============================================================*/
/* Table: LOCALIZACAO_PRODUTO                                   */
/*==============================================================*/
create table LOCALIZACAO_PRODUTO 
(
   ID_LOCALIZACAO_PRODUTO integer                        not null,
   ID_PRODUTO           integer                        null,
   LOCALIZACAO_AREA     varchar(150)                   null,
   constraint PK_LOCALIZACAO_PRODUTO primary key (ID_LOCALIZACAO_PRODUTO)
);

/*==============================================================*/
/* Index: LOCALIZACAO_PRODUTO_PK                                */
/*==============================================================*/
create unique index LOCALIZACAO_PRODUTO_PK on LOCALIZACAO_PRODUTO (
ID_LOCALIZACAO_PRODUTO ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_LOCALIZACAO2_FK                           */
/*==============================================================*/
create index PRODUTO_TEM_LOCALIZACAO2_FK on LOCALIZACAO_PRODUTO (
ID_PRODUTO ASC
);

/*==============================================================*/
/* Table: MUSICA                                                */
/*==============================================================*/
create table MUSICA 
(
   ID_MUSICA            integer                        not null,
   NOME                 varchar(150)                   null,
   TEMPO                time                           null,
   OBSERVACOES          varchar(150)                   null,
   constraint PK_MUSICA primary key (ID_MUSICA)
);

/*==============================================================*/
/* Index: MUSICA_PK                                             */
/*==============================================================*/
create unique index MUSICA_PK on MUSICA (
ID_MUSICA ASC
);

/*==============================================================*/
/* Table: PRODUTO                                               */
/*==============================================================*/
create table PRODUTO 
(
   TITULO               varchar(150)                   null,
   ANO_PUBLOCACAO       timestamp                      null,
   PRECO_CUSTO          float                          null,
   PRECO_VENDA          float                          null,
   ESTILO_MUSICAL       varchar(150)                   null,
   ID_PRODUTO           integer                        not null,
   ID_LOCALIZACAO_PRODUTO integer                        null,
   ID_EDITORA           integer                        null,
   ID_TIPO              integer                        null,
   constraint PK_PRODUTO primary key (ID_PRODUTO)
);

/*==============================================================*/
/* Index: PRODUTO_PK                                            */
/*==============================================================*/
create unique index PRODUTO_PK on PRODUTO (
ID_PRODUTO ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_LOCALIZACAO_FK                            */
/*==============================================================*/
create index PRODUTO_TEM_LOCALIZACAO_FK on PRODUTO (
ID_LOCALIZACAO_PRODUTO ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_EDITORA_FK                                */
/*==============================================================*/
create index PRODUTO_TEM_EDITORA_FK on PRODUTO (
ID_EDITORA ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_TIPO2_FK                                  */
/*==============================================================*/
create index PRODUTO_TEM_TIPO2_FK on PRODUTO (
ID_TIPO ASC
);

/*==============================================================*/
/* Table: PRODUTO_TEM_AUTOR                                     */
/*==============================================================*/
create table PRODUTO_TEM_AUTOR 
(
   ID_PRODUTO           integer                        not null,
   ID_AUTOR             integer                        not null,
   constraint PK_PRODUTO_TEM_AUTOR primary key clustered (ID_PRODUTO, ID_AUTOR)
);

/*==============================================================*/
/* Index: PRODUTO_TEM_AUTOR_PK                                  */
/*==============================================================*/
create unique clustered index PRODUTO_TEM_AUTOR_PK on PRODUTO_TEM_AUTOR (
ID_PRODUTO ASC,
ID_AUTOR ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_AUTOR_FK                                  */
/*==============================================================*/
create index PRODUTO_TEM_AUTOR_FK on PRODUTO_TEM_AUTOR (
ID_PRODUTO ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_AUTOR2_FK                                 */
/*==============================================================*/
create index PRODUTO_TEM_AUTOR2_FK on PRODUTO_TEM_AUTOR (
ID_AUTOR ASC
);

/*==============================================================*/
/* Table: PRODUTO_TEM_MUSICA                                    */
/*==============================================================*/
create table PRODUTO_TEM_MUSICA 
(
   ID_PRODUTO           integer                        not null,
   ID_MUSICA            integer                        not null,
   constraint PK_PRODUTO_TEM_MUSICA primary key clustered (ID_PRODUTO, ID_MUSICA)
);

/*==============================================================*/
/* Index: PRODUTO_TEM_MUSICA_PK                                 */
/*==============================================================*/
create unique clustered index PRODUTO_TEM_MUSICA_PK on PRODUTO_TEM_MUSICA (
ID_PRODUTO ASC,
ID_MUSICA ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_MUSICA_FK                                 */
/*==============================================================*/
create index PRODUTO_TEM_MUSICA_FK on PRODUTO_TEM_MUSICA (
ID_PRODUTO ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_MUSICA2_FK                                */
/*==============================================================*/
create index PRODUTO_TEM_MUSICA2_FK on PRODUTO_TEM_MUSICA (
ID_MUSICA ASC
);

/*==============================================================*/
/* Table: PROMOCOES                                             */
/*==============================================================*/
create table PROMOCOES 
(
   ID_PROMOCOES         integer                        not null,
   VALOR_DESCONTO       float(10)                      null,
   DATA_INICIO          timestamp                      null,
   DATA_FIM             timestamp                      null,
   constraint PK_PROMOCOES primary key (ID_PROMOCOES)
);

/*==============================================================*/
/* Index: PROMOCOES_PK                                          */
/*==============================================================*/
create unique index PROMOCOES_PK on PROMOCOES (
ID_PROMOCOES ASC
);

/*==============================================================*/
/* Table: TIPO                                                  */
/*==============================================================*/
create table TIPO 
(
   ID_TIPO              integer                        not null,
   ID_PRODUTO           integer                        not null,
   TIPO_PRODUTO         varchar(150)                   null,
   constraint PK_TIPO primary key (ID_TIPO)
);

/*==============================================================*/
/* Index: TIPO_PK                                               */
/*==============================================================*/
create unique index TIPO_PK on TIPO (
ID_TIPO ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_TIPO_FK                                   */
/*==============================================================*/
create index PRODUTO_TEM_TIPO_FK on TIPO (
ID_PRODUTO ASC
);

/*==============================================================*/
/* Table: VENDAS                                                */
/*==============================================================*/
create table VENDAS 
(
   ID_EMPREGADOS        integer                        not null,
   ID_VENDA             integer                        not null,
   ID_CLIENTE           integer                        null,
   ID_PRODUTO           integer                        null,
   ID_PROMOCOES         integer                        null,
   DATA                 timestamp                      null,
   METODO_PAGAMENTO     varchar(150)                   null,
   QUANTIDADE           integer                        null,
   PRECO_UNIDADE        float(0)                       null,
   constraint PK_VENDAS primary key (ID_EMPREGADOS, ID_VENDA)
);

/*==============================================================*/
/* Index: VENDAS_PK                                             */
/*==============================================================*/
create unique index VENDAS_PK on VENDAS (
ID_EMPREGADOS ASC,
ID_VENDA ASC
);

/*==============================================================*/
/* Index: VENDAS_TEM_PROMOCAO_FK                                */
/*==============================================================*/
create index VENDAS_TEM_PROMOCAO_FK on VENDAS (
ID_PROMOCOES ASC
);

/*==============================================================*/
/* Index: REALIZAM_FK                                           */
/*==============================================================*/
create index REALIZAM_FK on VENDAS (
ID_CLIENTE ASC
);

/*==============================================================*/
/* Index: PRODUTO_TEM_VARIAS_VENDAS_FK                          */
/*==============================================================*/
create index PRODUTO_TEM_VARIAS_VENDAS_FK on VENDAS (
ID_PRODUTO ASC
);

/*==============================================================*/
/* Index: VENDA_TEM_EMPREGADO_FK                                */
/*==============================================================*/
create index VENDA_TEM_EMPREGADO_FK on VENDAS (
ID_EMPREGADOS ASC
);

alter table AUTOR
   add constraint FK_AUTOR_CONTRATO__CONTRATO foreign key (ID_CONTRATO)
      references CONTRATO (ID_CONTRATO)
      on update restrict
      on delete restrict;

alter table CONTRATO
   add constraint FK_CONTRATO_CONTRATO__AUTOR foreign key (ID_AUTOR)
      references AUTOR (ID_AUTOR)
      on update restrict
      on delete restrict;

alter table CONTRATO
   add constraint FK_CONTRATO_CONTRATO__EDITORA foreign key (ID_EDITORA)
      references EDITORA (ID_EDITORA)
      on update restrict
      on delete restrict;

alter table EDITORA
   add constraint FK_EDITORA_CONTRATO__CONTRATO foreign key (ID_CONTRATO)
      references CONTRATO (ID_CONTRATO)
      on update restrict
      on delete restrict;

alter table EDITORA_TEM_TIPO
   add constraint FK_EDITORA__EDITORA_T_TIPO foreign key (ID_TIPO)
      references TIPO (ID_TIPO)
      on update restrict
      on delete restrict;

alter table EDITORA_TEM_TIPO
   add constraint FK_EDITORA__EDITORA_T_EDITORA foreign key (ID_EDITORA)
      references EDITORA (ID_EDITORA)
      on update restrict
      on delete restrict;

alter table ENCOMENDA
   add constraint FK_ENCOMEND_EMPREGADO_EMPREGAD foreign key (ID_EMPREGADOS)
      references EMPREGADOS (ID_EMPREGADOS)
      on update restrict
      on delete restrict;

alter table ENCOMENDA_TEM_PRODUTOS
   add constraint FK_ENCOMEND_ENCOMENDA_ENCOMEND foreign key (ID_ENCOMENDA)
      references ENCOMENDA (ID_ENCOMENDA)
      on update restrict
      on delete restrict;

alter table ENCOMENDA_TEM_PRODUTOS
   add constraint FK_ENCOMEND_ENCOMENDA_PRODUTO foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO)
      on update restrict
      on delete restrict;

alter table FORNECEDOR_TEM_PRODUTOS
   add constraint FK_FORNECED_FORNECEDO_FORNECED foreign key (ID_ATRIBUTO)
      references FORNECEDOR (ID_ATRIBUTO)
      on update restrict
      on delete restrict;

alter table FORNECEDOR_TEM_PRODUTOS
   add constraint FK_FORNECED_FORNECEDO_PRODUTO foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO)
      on update restrict
      on delete restrict;

alter table LOCALIZACAO_PRODUTO
   add constraint FK_LOCALIZA_PRODUTO_T_PRODUTO foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO)
      on update restrict
      on delete restrict;

alter table PRODUTO
   add constraint FK_PRODUTO_PRODUTO_T_EDITORA foreign key (ID_EDITORA)
      references EDITORA (ID_EDITORA)
      on update restrict
      on delete restrict;

alter table PRODUTO
   add constraint FK_PRODUTO_PRODUTO_T_LOCALIZA foreign key (ID_LOCALIZACAO_PRODUTO)
      references LOCALIZACAO_PRODUTO (ID_LOCALIZACAO_PRODUTO)
      on update restrict
      on delete restrict;

alter table PRODUTO
   add constraint FK_PRODUTO_PRODUTO_T_TIPO foreign key (ID_TIPO)
      references TIPO (ID_TIPO)
      on update restrict
      on delete restrict;

alter table PRODUTO_TEM_AUTOR
   add constraint FK_PRODUTO__PRODUTO_T_PRODUTO foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO)
      on update restrict
      on delete restrict;

alter table PRODUTO_TEM_AUTOR
   add constraint FK_PRODUTO__PRODUTO_T_AUTOR foreign key (ID_AUTOR)
      references AUTOR (ID_AUTOR)
      on update restrict
      on delete restrict;

alter table PRODUTO_TEM_MUSICA
   add constraint FK_PRODUTO__PRODUTO_T_PRODUTO foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO)
      on update restrict
      on delete restrict;

alter table PRODUTO_TEM_MUSICA
   add constraint FK_PRODUTO__PRODUTO_T_MUSICA foreign key (ID_MUSICA)
      references MUSICA (ID_MUSICA)
      on update restrict
      on delete restrict;

alter table TIPO
   add constraint FK_TIPO_PRODUTO_T_PRODUTO foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO)
      on update restrict
      on delete restrict;

alter table VENDAS
   add constraint FK_VENDAS_PRODUTO_T_PRODUTO foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO)
      on update restrict
      on delete restrict;

alter table VENDAS
   add constraint FK_VENDAS_REALIZAM_CLIENTE_ foreign key (ID_CLIENTE)
      references CLIENTE_ESPECIAIS (ID_CLIENTE)
      on update restrict
      on delete restrict;

alter table VENDAS
   add constraint FK_VENDAS_VENDAS_TE_PROMOCOE foreign key (ID_PROMOCOES)
      references PROMOCOES (ID_PROMOCOES)
      on update restrict
      on delete restrict;

alter table VENDAS
   add constraint FK_VENDAS_VENDA_TEM_EMPREGAD foreign key (ID_EMPREGADOS)
      references EMPREGADOS (ID_EMPREGADOS)
      on update restrict
      on delete restrict;

