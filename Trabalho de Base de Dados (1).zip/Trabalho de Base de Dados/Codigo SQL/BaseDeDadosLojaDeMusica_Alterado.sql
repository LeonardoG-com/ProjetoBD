drop table if exists AUTOR;

drop table if exists CLIENTE_ESPECIAIS;

drop table if exists CONTRATO;

drop table if exists EDITORA;

drop table if exists EDITORA_TEM_TIPO;

drop table if exists EMPREGADOS;

drop table if exists ENCOMENDA;

drop table if exists ENCOMENDA_TEM_PRODUTOS;

drop table if exists FORNECEDOR;

drop table if exists FORNECEDOR_TEM_PRODUTOS;

drop table if exists LOCALIZACAO_PRODUTO;

drop table if exists MUSICA;

drop table if exists PRODUTO;

drop table if exists PRODUTO_TEM_AUTOR;

drop table if exists PRODUTO_TEM_MUSICA;

drop table if exists PROMOCOES;

drop table if exists TIPO;

drop table if exists VENDAS;

/*==============================================================*/
/* Table: AUTOR                                                 */
/*==============================================================*/
create table AUTOR
(
   ID_AUTOR             int not null AUTO_INCREMENT,
   ID_CONTRATO          int,
   NOME                 varchar(150),
   DATA_NASCIMENTO      DATE,
   EMAIL                varchar(200),
   PAGINA_WEB           varchar(150),
   MORADA               varchar(150),
   CLUBE_DE_FAS         varchar(150),
   OBSERVACOES          varchar(150),
   primary key (ID_AUTOR)
);

/*==============================================================*/
/* Table: CLIENTE_ESPECIAIS                                     */
/*==============================================================*/
create table CLIENTE_ESPECIAIS
(
   ID_CLIENTE           int not null AUTO_INCREMENT,
   NOME                 varchar(150),
   EMAIL                varchar(200),
   primary key (ID_CLIENTE)
);

/*==============================================================*/
/* Table: CONTRATO                                              */
/*==============================================================*/
create table CONTRATO
(
   ID_CONTRATO          int not null AUTO_INCREMENT,
   ID_EDITORA           int not null,
   ID_AUTOR             int not null,
   DATA_INICIO          timestamp,
   DATA_FIM             timestamp,
   primary key (ID_CONTRATO)
);

/*==============================================================*/
/* Table: EDITORA                                               */
/*==============================================================*/
create table EDITORA
(
   ID_EDITORA           int not null AUTO_INCREMENT,
   ID_CONTRATO          int,
   NOME                 varchar(150),
   MORADA               varchar(150),
   EMAIL                varchar(200),
   PAGINA_WEB           varchar(150),
   ESTILO_MUSICAL       varchar(150),
   OBSERVACOES          varchar(150),
   primary key (ID_EDITORA)
);

/*==============================================================*/
/* Table: EDITORA_TEM_TIPO                                      */
/*==============================================================*/
create table EDITORA_TEM_TIPO
(
   ID_TIPO              int not null,
   ID_EDITORA           int not null,
   primary key (ID_TIPO, ID_EDITORA)
);

/*==============================================================*/
/* Table: EMPREGADOS                                            */
/*==============================================================*/
create table EMPREGADOS
(
   ID_EMPREGADOS        int not null AUTO_INCREMENT,
   NOME                 varchar(150),
   DATA_ENTRADA         timestamp,
   DATA_SAIDA           timestamp,
   primary key (ID_EMPREGADOS)
);

/*==============================================================*/
/* Table: ENCOMENDA                                             */
/*==============================================================*/
create table ENCOMENDA
(
   ID_ENCOMENDA         int not null AUTO_INCREMENT,
   ID_EMPREGADOS        int,
   DATA                 timestamp,
   ESTADO               varchar(50),
   primary key (ID_ENCOMENDA)
);

/*==============================================================*/
/* Table: ENCOMENDA_TEM_PRODUTOS                                */
/*==============================================================*/
create table ENCOMENDA_TEM_PRODUTOS
(
   ID_ENCOMENDA         int not null,
   ID_PRODUTO           int not null,
   primary key (ID_ENCOMENDA, ID_PRODUTO)
);

/*==============================================================*/
/* Table: FORNECEDOR                                            */
/*==============================================================*/
create table FORNECEDOR
(
   ID_ATRIBUTO          int not null AUTO_INCREMENT,
   NOME                 varchar(150),
   MORADA               varchar(150),
   CONTACTO             int,
   EMAIL                varchar(200),
   OBSERVACOES          varchar(150),
   primary key (ID_ATRIBUTO)
);

/*==============================================================*/
/* Table: FORNECEDOR_TEM_PRODUTOS                               */
/*==============================================================*/
create table FORNECEDOR_TEM_PRODUTOS
(
   ID_ATRIBUTO          int not null,
   ID_PRODUTO           int not null,
   primary key (ID_ATRIBUTO, ID_PRODUTO)
);

/*==============================================================*/
/* Table: LOCALIZACAO_PRODUTO                                   */
/*==============================================================*/
create table LOCALIZACAO_PRODUTO
(
   ID_LOCALIZACAO_PRODUTO int not null AUTO_INCREMENT,
   ID_PRODUTO           int,
   LOCALIZACAO_AREA     varchar(150),
   primary key (ID_LOCALIZACAO_PRODUTO)
);

/*==============================================================*/
/* Table: MUSICA                                                */
/*==============================================================*/
create table MUSICA
(
   ID_MUSICA            int not null AUTO_INCREMENT,
   NOME                 varchar(150),
   TEMPO                time,
   OBSERVACOES          varchar(150),
   primary key (ID_MUSICA)
);

/*==============================================================*/
/* Table: PRODUTO                                               */
/*==============================================================*/
create table PRODUTO
(
   TITULO               varchar(150),
   ANO_PUBLOCACAO       date,
   PRECO_CUSTO          float,
   PRECO_VENDA          float,
   ESTILO_MUSICAL       varchar(150),
   ID_PRODUTO           int not null AUTO_INCREMENT,
   ID_LOCALIZACAO_PRODUTO int,
   ID_EDITORA           int,
   ID_TIPO              int,
   primary key (ID_PRODUTO)
);

/*==============================================================*/
/* Table: PRODUTO_TEM_AUTOR                                     */
/*==============================================================*/
create table PRODUTO_TEM_AUTOR
(
   ID_PRODUTO           int not null,
   ID_AUTOR             int not null,
   primary key (ID_PRODUTO, ID_AUTOR)
);

/*==============================================================*/
/* Table: PRODUTO_TEM_MUSICA                                    */
/*==============================================================*/
create table PRODUTO_TEM_MUSICA
(
   ID_PRODUTO           int not null,
   ID_MUSICA            int not null,
   primary key (ID_PRODUTO, ID_MUSICA)
);

/*==============================================================*/
/* Table: PROMOCOES                                             */
/*==============================================================*/
create table PROMOCOES
(
   ID_PROMOCOES         int not null AUTO_INCREMENT,
   VALOR_DESCONTO       float(10),
   DATA_INICIO          timestamp,
   DATA_FIM             timestamp,
   primary key (ID_PROMOCOES)
);

/*==============================================================*/
/* Table: TIPO                                                  */
/*==============================================================*/
create table TIPO
(
   ID_TIPO              int not null AUTO_INCREMENT,
   ID_PRODUTO           int not null,
   TIPO_PRODUTO         varchar(150),
   primary key (ID_TIPO)
);

/*==============================================================*/
/* Table: VENDAS                                                */
/*==============================================================*/
create table VENDAS
(
   ID_VENDA             int not null auto_increment,
   ID_EMPREGADOS        int not null,
   ID_CLIENTE           int,
   ID_PRODUTO           int,
   ID_PROMOCOES         int,
   DATA                 timestamp,
   METODO_PAGAMENTO     varchar(150),
   QUANTIDADE           int,
   PRECO_UNIDADE        float(10,2),
   primary key (ID_VENDA)
);

alter table AUTOR add constraint FK_CONTRATO_TEM_AUTOR foreign key (ID_CONTRATO)
      references CONTRATO (ID_CONTRATO) on delete restrict on update restrict;

alter table CONTRATO add constraint FK_CONTRATO_TEM_AUTOR2 foreign key (ID_AUTOR)
      references AUTOR (ID_AUTOR) on delete restrict on update restrict;

alter table CONTRATO add constraint FK_CONTRATO_TEM_EDITORA2 foreign key (ID_EDITORA)
      references EDITORA (ID_EDITORA) on delete restrict on update restrict;

alter table EDITORA add constraint FK_CONTRATO_TEM_EDITORA foreign key (ID_CONTRATO)
      references CONTRATO (ID_CONTRATO) on delete restrict on update restrict;

alter table EDITORA_TEM_TIPO add constraint FK_EDITORA_TEM_TIPO foreign key (ID_TIPO)
      references TIPO (ID_TIPO) on delete restrict on update restrict;

alter table EDITORA_TEM_TIPO add constraint FK_EDITORA_TEM_TIPO2 foreign key (ID_EDITORA)
      references EDITORA (ID_EDITORA) on delete restrict on update restrict;

alter table ENCOMENDA add constraint FK_EMPREGADO_ENCOMENDA foreign key (ID_EMPREGADOS)
      references EMPREGADOS (ID_EMPREGADOS) on delete restrict on update restrict;

alter table ENCOMENDA_TEM_PRODUTOS add constraint FK_ENCOMENDA_TEM_PRODUTOS foreign key (ID_ENCOMENDA)
      references ENCOMENDA (ID_ENCOMENDA) on delete restrict on update restrict;

alter table ENCOMENDA_TEM_PRODUTOS add constraint FK_ENCOMENDA_TEM_PRODUTOS2 foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO) on delete restrict on update restrict;

alter table FORNECEDOR_TEM_PRODUTOS add constraint FK_FORNECEDOR_TEM_PRODUTOS foreign key (ID_ATRIBUTO)
      references FORNECEDOR (ID_ATRIBUTO) on delete restrict on update restrict;

alter table FORNECEDOR_TEM_PRODUTOS add constraint FK_FORNECEDOR_TEM_PRODUTOS2 foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO) on delete restrict on update restrict;

alter table LOCALIZACAO_PRODUTO add constraint FK_PRODUTO_TEM_LOCALIZACAO2 foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO) on delete restrict on update restrict;

alter table PRODUTO add constraint FK_PRODUTO_TEM_EDITORA foreign key (ID_EDITORA)
      references EDITORA (ID_EDITORA) on delete restrict on update restrict;

alter table PRODUTO add constraint FK_PRODUTO_TEM_LOCALIZACAO foreign key (ID_LOCALIZACAO_PRODUTO)
      references LOCALIZACAO_PRODUTO (ID_LOCALIZACAO_PRODUTO) on delete restrict on update restrict;

alter table PRODUTO add constraint FK_PRODUTO_TEM_TIPO2 foreign key (ID_TIPO)
      references TIPO (ID_TIPO) on delete restrict on update restrict;

alter table PRODUTO_TEM_AUTOR add constraint FK_PRODUTO_TEM_AUTOR foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO) on delete restrict on update restrict;

alter table PRODUTO_TEM_AUTOR add constraint FK_PRODUTO_TEM_AUTOR2 foreign key (ID_AUTOR)
      references AUTOR (ID_AUTOR) on delete restrict on update restrict;

alter table PRODUTO_TEM_MUSICA add constraint FK_PRODUTO_TEM_MUSICA foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO) on delete restrict on update restrict;

alter table PRODUTO_TEM_MUSICA add constraint FK_PRODUTO_TEM_MUSICA2 foreign key (ID_MUSICA)
      references MUSICA (ID_MUSICA) on delete restrict on update restrict;

alter table TIPO add constraint FK_PRODUTO_TEM_TIPO foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO) on delete restrict on update restrict;

alter table VENDAS add constraint FK_PRODUTO_TEM_VARIAS_VENDAS foreign key (ID_PRODUTO)
      references PRODUTO (ID_PRODUTO) on delete restrict on update restrict;

alter table VENDAS add constraint FK_REALIZAM foreign key (ID_CLIENTE)
      references CLIENTE_ESPECIAIS (ID_CLIENTE) on delete restrict on update restrict;

alter table VENDAS add constraint FK_VENDAS_TEM_PROMOCAO foreign key (ID_PROMOCOES)
      references PROMOCOES (ID_PROMOCOES) on delete restrict on update restrict;

alter table VENDAS add constraint FK_VENDA_TEM_EMPREGADO foreign key (ID_EMPREGADOS)
      references EMPREGADOS (ID_EMPREGADOS) on delete restrict on update restrict;
